package com.infinity;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import com.infinity.model.Student;
import com.infinity.service.StudentService;

@SpringBootApplication
public class App2 {
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(App2.class, args);

		StudentService service = context.getBean(StudentService.class);

		Student student = context.getBean(Student.class);

		List<Student> list= service.allStudents();
		for(Student s:list) {
			System.out.println(s.getStudentId());
			System.out.println(s.getStudentName());
			System.out.println(s.getStudentScore());
			System.out.println("------------------------------");
		}
	}
}
