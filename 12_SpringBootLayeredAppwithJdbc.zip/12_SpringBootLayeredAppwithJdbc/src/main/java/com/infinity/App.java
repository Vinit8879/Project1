package com.infinity;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import com.infinity.model.Student;
import com.infinity.service.StudentService;

@SpringBootApplication
public class App {
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(App.class, args);

		StudentService service = context.getBean(StudentService.class);

		Student student = context.getBean(Student.class);

		student.setStudentId(101);
		student.setStudentName("vinit");
		student.setStudentScore(100);
		
		
		  Student student2=context.getBean(Student.class);
		  
		  student.setStudentId(101); 
		  student.setStudentName("Vaishnavi");
		  student.setStudentScore(95);
		 
		/*student.getDepartment().setDeptId(10);
		student.getDepartment().setDeptName("EC");*/
		  
		/*
		 * boolean result=service.updatedStudent(student2); if(result) {
		 * System.out.println("Data updated succesfully"); } else {
		 * System.out.println("There is some problem"); }
		 */

		
		  Student result2= service.findStudentById(101);
		  System.out.println("Student Id is "+result2.getStudentId());
		  System.out.println("Student Name is "+result2.getStudentName());
		  System.out.println("Student Score is "+result2.getStudentScore());
		/*
		 * boolean result=service.addStudent(student); if(result) {
		 * System.out.println("Student Data Added sucessfully");}
		 * 
		 * else { System.out.println("There is problem"); }
		 */
		 
			
		/*
		 * boolean deleteresult=service.removeStudentbyId(101); if(deleteresult) {
		 * System.out.println("Student Data removed sucessfully");}
		 * 
		 * else { System.out.println("There is problem"); }
		 */
		/*
		 * Student result = service.findStudentById(101); System.out.println(result); if
		 * (result != null) System.out.println(result.getDepartment());
		 */

		/*
		 * List<Student> details = service.findallStudent();
		 * System.out.println(details);
		 * 
		 * System.out.println(service.findStudentbyName("vinit"));
		 * 
		 * System.out.println(service.findStudentbyScore(5, 110));
		 * //System.out.println(byName);
		 * 
		 * System.out.println(service.deletebyId(105));
		 */

	}
}
