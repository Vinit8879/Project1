package com.infinity.repository;

import java.util.List;

import com.infinity.model.Student;

public interface StudentRespository {

	public boolean createStudent(Student student);

	public Student readStudentById(int StudentId);
	
	public boolean deleteStudentbyId(int studentId);
	
	public boolean updateStudent(Student student);
	
	public List<Student> readAllStudents();
}
