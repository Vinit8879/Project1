package com.infinity.repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.infinity.model.Student;

@Repository
public class StudentRespositoryImpl implements StudentRespository {
	
	@Autowired
	private JdbcTemplate template; 
	
	@Override
	public boolean createStudent(Student student) {
		String query="Insert Into students(Student_Id,Student_Name,Student_Score) values(?,?,?)";
		int result = template.update(query,student.getStudentId(),student.getStudentName(),student.getStudentScore());
		return result ==1 ? true : false;
	}

	//RowMapper
	@Override
	public Student readStudentById(int StudentId) {
		String query="Select*from Students where Student_Id= "+StudentId;
		Student student=template.queryForObject(query,new StudentRowMapper());
		return student;
		
	}
	
	@Override
	public boolean deleteStudentbyId(int studentId) {
		String query="Delete from students where student_id="+studentId;
		int result=template.update(query);
		return result==1?true:false;
		
	}

	@Override
	public boolean updateStudent(Student student) {
		String query="update students set Student_name= ?, Student_Score=? where Student_id= ?";
		//String query1="update students set Student_name=? where Student_id=?";
		
		int result= template.update(query,student.getStudentName(),student.getStudentScore(),student.getStudentId());
		
		return result ==1 ? true : false;
	}

	@Override
	public List<Student> readAllStudents() {
		String query="Select*from Students";
		
		return template.query(query,new StudentRowMapper());
		
	}

}
